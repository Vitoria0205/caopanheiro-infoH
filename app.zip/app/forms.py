# app/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario, Cidade, Formulario
from .models import UF_CHOICES  # Importe as opções


class PreAdocaoForm(forms.ModelForm):
    class Meta:
        model = Formulario
        fields = [
            'tipo_moradia',
            'situacao_moradia',
            'tem_cachorro',
            'detalhes_cachorro',
            'experiencia_adocao',
            'motivo_adocao',
            'disponibilidade',
            'compromisso',
        ]
        widgets = {
            'tipo_moradia': forms.Select(attrs={'class': 'form-select'}),
            'situacao_moradia': forms.Select(attrs={'class': 'form-select'}),
            'tem_cachorro': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'detalhes_cachorro': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Ex: 1 cachorro, SRD, 3 anos'
            }),
            'experiencia_adocao': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'motivo_adocao': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Conte um pouco sobre sua motivação...'
            }),
            'disponibilidade': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Ex: Tenho 4h livres por dia, quintal cercado, etc.'
            }),
            'compromisso': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'tem_cachorro': 'Já tem cachorro(s) em casa?',
            'experiencia_adocao': 'Já teve experiência com adoção?',
            'compromisso': 'Confirmo que estou ciente das responsabilidades de adotar um animal e me comprometo a cuidar dele com amor, respeito e dedicação.',
        }

    def clean(self):
        cleaned_data = super().clean()
        tem_cachorro = cleaned_data.get('tem_cachorro')
        detalhes = cleaned_data.get('detalhes_cachorro')
        compromisso = cleaned_data.get('compromisso')

        if tem_cachorro and not detalhes:
            self.add_error('detalhes_cachorro', 'Por favor, descreva os cachorros que você já tem.')

        if not compromisso:
            self.add_error('compromisso', 'Você deve aceitar o compromisso de cuidados.')

        return cleaned_data

class CadastroForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'seu@email.com'}),
        label="E-mail"
    )
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Digite seu nome'}),
        label="Nome"
    )
    last_name = forms.CharField(
        max_length=150,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Digite seu sobrenome'}),
        label="Sobrenome"
    )
    data_nascimento = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        label="Data de Nascimento"
    )
    telefone = forms.CharField(
        max_length=15,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '(00) 00000-0000'}),
        label="Telefone"
    )
    endereco = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Rua, número, bairro...'}),
        required=False,
        label="Endereço"
    )
   # Em CadastroForm
    cidade_texto = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: São Paulo, Rio de Janeiro...'}),
        label="Cidade"
    )
    
    uf = forms.ChoiceField(
    choices=[('', 'UF')] + UF_CHOICES,
    required=False,
    widget=forms.Select(attrs={
        'class': 'form-select form-select-sm',
        'style': 'padding: 0.75rem 0.5rem; font-size: 0.9rem; text-align: center; width: 100%;'
    }),
    label="UF"
)
    newsletter = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label="Quero receber newsletter com novidades sobre adoções"
    )
    termos_aceitos = forms.BooleanField(
        required=True,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label='Aceito os <a href="#" target="_blank">termos e condições</a> e a <a href="#" target="_blank">política de privacidade</a>'
    )

    # 🔑 Defina os campos de senha EXPLICITAMENTE
    password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Mínimo 8 caracteres'}),
        label="Senha"
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirme sua senha'}),
        label="Confirmar Senha"
    )
    
    
    class Meta:
        model = Usuario
        fields = (
            'first_name', 'last_name', 'email',
            'data_nascimento', 'telefone', 'endereco',
            'newsletter', 'password1', 'password2'
        )

    def save(self, commit=True):
        user = super().save(commit=False)
        # ... outros campos ...

        nome_cidade = self.cleaned_data.get('cidade_texto')
        uf = self.cleaned_data.get('uf')

        if nome_cidade and uf:
            # Busca ou cria a cidade com base no nome + UF
            cidade_obj, created = Cidade.objects.get_or_create(
                nome__iexact=nome_cidade.strip(),
                uf=uf,
                defaults={'nome': nome_cidade.strip().title()}
            )
            user.cidade = cidade_obj
        else:
            user.cidade = None

        if commit:
            user.save()
        return user
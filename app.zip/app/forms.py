# app/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model

Usuario = get_user_model()


class CadastroForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'seu@email.com'}),
        label="E-mail"
    )
    idade = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'min': '18', 'placeholder': 'Ex: 25'}),
        label="Idade"
    )
    telefone = forms.CharField(
        max_length=15,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '(00) 00000-0000'}),
        label="Telefone"
    )
    endereco = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Rua, número, bairro...'}),
        required=False,
        label="Endereço"
    )
    cidade = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: São Paulo'}),
        label="Cidade"
    )
    newsletter = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label="Quero receber newsletter com novidades sobre adoções"
    )
    termos_aceitos = forms.BooleanField(
        required=True,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label='Aceito os <a href="#" target="_blank">termos e condições</a> e a <a href="#" target="_blank">política de privacidade</a>'
    )

    class Meta:
        model = Usuario
        fields = ('username', 'email', 'idade', 'telefone', 'endereco', 'cidade', 'password1', 'password2')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Escolha um nome de usuário'}),
        }
        labels = {
            'username': 'Nome de usuário',
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.idade = self.cleaned_data.get('idade')
        user.telefone = self.cleaned_data.get('telefone')
        user.endereco = self.cleaned_data.get('endereco')
        user.cidade = self.cleaned_data.get('cidade')
        user.newsletter = self.cleaned_data.get('newsletter', False)
        user.is_staff = True   # ✅ Acesso ao Django Admin
        user.is_active = True
        if commit:
            user.save()
        return user
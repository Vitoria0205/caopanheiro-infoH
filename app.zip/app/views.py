# app/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from django.views import View
from django.contrib.auth import authenticate, login, logout
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .forms import CadastroForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden


# ====== VIEWS DE PÁGINAS ESTÁTICAS ======
class IndexView(View):
    def get(self, request):
        return render(request, 'index.html')


class HistoriaView(View):
    def get(self, request):
        return render(request, 'historia.html')


class LocalizacaoView(View):
    def get(self, request):
        return render(request, 'localizacao.html')


# ====== FORMULÁRIO DE LOGIN POR E-MAIL ======
class EmailAuthenticationForm(AuthenticationForm):
    username = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'seu@email.com'}),
        label="E-mail"
    )


# ====== VIEW DE LOGIN ======
def login_view(request):
    if request.method == 'POST':
        form = EmailAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=email, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Bem-vindo de volta, {user.email}!')
                return redirect('/admin/')  # ✅ Vai direto para o admin
            else:
                messages.error(request, 'E-mail ou senha inválidos.')
        else:
            messages.error(request, 'E-mail ou senha inválidos.')
    else:
        form = EmailAuthenticationForm()
    return render(request, 'login.html', {'form': form})


# ====== VIEW DE CADASTRO ======
def cadastro_view(request):
    if request.method == 'POST':
        form = CadastroForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Conta criada com sucesso! Faça login.')
            return redirect('login')
        else:
            messages.error(request, 'Corrija os erros abaixo.')
    else:
        form = CadastroForm()
    return render(request, 'cadastro.html', {'form': form})


# ====== VIEW DE LOGOUT ======
def logout_view(request):
    logout(request)
    messages.success(request, "Você saiu da sua conta.")
    return redirect('login')

# core/views.py

@login_required
def custom_login_redirect(request):
    """
    Redireciona após login:
    - Admin/staff → /admin/
    - Usuário comum → /
    """
    if request.user.is_superuser or request.user.is_staff:
        return redirect('/admin/')
    else:
        return redirect('/')
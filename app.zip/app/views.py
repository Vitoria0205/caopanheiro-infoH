# app/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Animal, Adocao, Caracteristica, Historia
from .forms import CadastroForm, PreAdocaoForm
from django.views import View
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db.models import Prefetch


# ====== VIEWS PÚBLICAS ======

class IndexView(View):
    def get(self, request):
        animais = Animal.objects.filter(adotado=False).select_related('caracteristica')
        context = {'animais': animais}
        if request.user.is_authenticated:
            adocoes_pendentes = Adocao.objects.filter(
                usuario=request.user,
                confirmacao=True,
                confirmacao_adotante=False
            )
            context['adocoes_pendentes'] = adocoes_pendentes
        return render(request, 'index.html', context)


class HistoriaView(View):
    def get(self, request):
        # Obtém IDs dos animais com adoção confirmada
        animais_adotados_ids = Adocao.objects.filter(confirmacao=True).values_list('animal_id', flat=True)
        
        # Busca os animais + suas histórias associadas (via relacionamento ManyToMany)
        animais_adotados = Animal.objects.filter(
            id__in=animais_adotados_ids
        ).prefetch_related(
            Prefetch('historia_set', queryset=Historia.objects.all(), to_attr='historias')
        ).select_related('caracteristica')

        # Prepara lista com animal + sua primeira história (ou None)
        animais_com_historia = []
        for animal in animais_adotados:
            historia = animal.historias[0] if animal.historias else None
            animais_com_historia.append({
                'animal': animal,
                'historia': historia
            })

        return render(request, 'historia.html', {'animais_com_historia': animais_com_historia})


class LocalizacaoView(View):
    def get(self, request):
        return render(request, 'localizacao.html')


# ====== VIEWS DE ANIMAIS ADOTADOS (OPCIONAL - pode ser removida) ======

# Se quiser manter a view individual por compatibilidade, deixe-a. Senão, remova.
class HistoriaIndividualView(View):
    def get(self, request, animal_id):
        # Redireciona para a página geral (boa prática se desativar a individual)
        return redirect('historia')


# ====== AUTENTICAÇÃO E OUTRAS VIEWS (SEM ALTERAÇÃO) ======

# ... (mantenha todas as demais views exatamente como estão: cadastro_view, login_view, etc.)
# Não alterei as funções abaixo porque não são relevantes para o escopo atual.

def cadastro_view(request):
    if request.method == 'POST':
        form = CadastroForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cadastro realizado com sucesso! Faça login para continuar.')
            return redirect('login')
        else:
            messages.error(request, 'Por favor, corrija os erros abaixo.')
    else:
        form = CadastroForm()
    return render(request, 'cadastro.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff or user.is_superuser:
                return redirect('/admin/')
            else:
                return redirect('index')
        else:
            messages.error(request, 'E-mail ou senha inválidos!')
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    messages.success(request, 'Você saiu da sua conta.')
    return redirect('index')


@login_required
def perfil(request):
    return render(request, 'perfil.html')


@login_required
def formulario_view(request, animal_id):
    animal = get_object_or_404(Animal, id=animal_id)
    if Adocao.objects.filter(animal=animal, confirmacao=True).exists():
        messages.warning(request, 'Este animal já foi adotado. Confira nossa página de histórias!')
        return redirect('index')

    if request.method == 'POST':
        form = PreAdocaoForm(request.POST)
        if form.is_valid():
            formulario = form.save(commit=False)
            formulario.usuario = request.user
            formulario.animal = animal
            formulario.save()
            messages.success(request, 'Formulário de pré-adoção enviado com sucesso! Em breve entraremos em contato.')
            return redirect('index')
        else:
            messages.error(request, 'Por favor, corrija os erros abaixo.')
    else:
        form = PreAdocaoForm()

    return render(request, 'formulario.html', {
        'form': form,
        'animal': animal,
        'user': request.user
    })


@login_required
def confirmacao_adocao_view(request, adocao_id):
    adocao = get_object_or_404(Adocao, id=adocao_id, usuario=request.user)

    if not adocao.confirmacao:
        messages.error(request, 'Esta adoção ainda não foi confirmada pela ONG.')
        return redirect('perfil')

    if adocao.confirmacao_adotante:
        messages.info(request, 'Você já confirmou esta adoção!')
        return redirect('perfil')

    if request.method == 'POST':
        adocao.confirmacao_adotante = True
        adocao.data_confirmacao_adotante = timezone.now()
        adocao.save()

        animal = adocao.animal
        animal.adotado = True
        animal.save()

        messages.success(request, 'Adoção confirmada com sucesso! Em breve entraremos em contato para agendar a entrega do seu novo amigo. 🐾')
        return redirect('perfil')

    return render(request, 'confirmacao_adocao.html', {
        'adocao': adocao,
        'animal': adocao.animal,
        'usuario': request.user
    })


@login_required
def notificacao(request):
    adocoes_pendentes = Adocao.objects.filter(
        usuario=request.user,
        confirmacao=True,
        confirmacao_adotante=False
    )
    adocoes_confirmadas = Adocao.objects.filter(
        usuario=request.user,
        confirmacao_adotante=True
    )
    return render(request, 'notificacao.html', {
        'adocoes_pendentes': adocoes_pendentes,
        'adocoes_confirmadas': adocoes_confirmadas,
    })
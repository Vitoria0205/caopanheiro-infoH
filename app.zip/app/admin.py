# app/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    Usuario, Cidade, Caracteristica,
    Animal, Formulario, Adocao, Doacao, Historia
)

@admin.register(Usuario)
class UsuarioAdmin(BaseUserAdmin):
    list_display = ('email', 'first_name', 'last_name', 'idade_display', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_superuser', 'is_active')
    search_fields = ('email', 'first_name', 'last_name')
    ordering = ('email',)

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Informações Pessoais', {
            'fields': ('first_name', 'last_name', 'data_nascimento', 'telefone', 'endereco', 'cidade', 'newsletter')
        }),
        ('Permissões', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        ('Datas Importantes', {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'email', 'first_name', 'last_name', 'data_nascimento',
                'password1', 'password2',
                'telefone', 'endereco', 'cidade', 'newsletter',
                'is_active', 'is_staff', 'is_superuser'
            ),
        }),
    )

    def idade_display(self, obj):
        return obj.idade
    idade_display.short_description = 'Idade'
    idade_display.admin_order_field = 'data_nascimento'


@admin.register(Adocao)
class AdocaoAdmin(admin.ModelAdmin):
    list_display = ('animal', 'usuario', 'confirmacao', 'confirmacao_adotante', 'data_adocao')
    list_filter = ('confirmacao', 'confirmacao_adotante', 'data_adocao')
    search_fields = ('animal__nome', 'usuario__email')
    readonly_fields = ('data_adocao', 'data_confirmacao_adotante')
    
    actions = ['marcar_como_confirmadas']

    def marcar_como_confirmadas(self, request, queryset):
        updated = queryset.update(confirmacao=True)
        self.message_user(request, f'{updated} adoções foram confirmadas.')
    marcar_como_confirmadas.short_description = "✅ Confirmar adoções selecionadas"


@admin.register(Historia)
class HistoriaAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'data_atualizacao', 'adocao')
    list_filter = ('data_atualizacao',)
    search_fields = ('titulo', 'descricao', 'envolvidos')
    filter_horizontal = ('animais',)
    fields = ('titulo', 'descricao', 'envolvidos', 'adocao', 'animais')
    readonly_fields = ('data_atualizacao',)


# Registra os demais modelos
admin.site.register(Cidade)
admin.site.register(Caracteristica)
admin.site.register(Animal)
admin.site.register(Formulario)
admin.site.register(Doacao)
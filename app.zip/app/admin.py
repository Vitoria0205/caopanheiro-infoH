# app/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import (
    Usuario, Pessoa, Cidade, Caracteristica,
    Animal, Formulario, Adocao, Doacao, Historia
)


# ====== MODELO DE USUÁRIO PERSONALIZADO ======
@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    # Campos exibidos na lista principal
    list_display = ('email', 'username', 'first_name', 'last_name', 'is_staff', 'newsletter', 'date_joined')
    # Campos pesquisáveis
    search_fields = ('email', 'username', 'first_name', 'last_name')
    # Filtros laterais
    list_filter = ('is_staff', 'is_active', 'newsletter', 'date_joined')
    # Ordenação padrão
    ordering = ('email',)
    # Para campos de relacionamento (grupos e permissões)
    filter_horizontal = ('groups', 'user_permissions')

    # Campos exibidos ao editar um usuário
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Informações Pessoais', {
            'fields': ('first_name', 'last_name', 'username', 'idade', 'telefone', 'endereco', 'cidade', 'newsletter')
        }),
        ('Permissões', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')
        }),
        ('Datas Importantes', {'fields': ('last_login', 'date_joined')}),
    )

    # Campos exibidos ao criar um novo usuário
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'email', 'username', 'first_name', 'last_name',
                'password1', 'password2',
                'idade', 'telefone', 'endereco', 'cidade', 'newsletter',
                'is_active', 'is_staff'
            ),
        }),
    )


# ====== REGISTRO DOS DEMAIS MODELOS ======
@admin.register(Pessoa)
class PessoaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'email', 'idade', 'cidade')
    search_fields = ('nome', 'email')
    list_filter = ('idade',)


@admin.register(Cidade)
class CidadeAdmin(admin.ModelAdmin):
    list_display = ('nome', 'uf')
    search_fields = ('nome',)
    list_filter = ('uf',)


@admin.register(Caracteristica)
class CaracteristicaAdmin(admin.ModelAdmin):
    list_display = ('raca', 'porte', 'idade', 'temperamento')
    list_filter = ('porte', 'idade', 'temperamento')


@admin.register(Animal)
class AnimalAdmin(admin.ModelAdmin):
    list_display = ('nome', 'caracteristica')
    search_fields = ('nome',)


@admin.register(Formulario)
class FormularioAdmin(admin.ModelAdmin):
    list_display = ('nome', 'pessoa', 'animal', 'data_solicitacao')
    list_filter = ('data_solicitacao',)


@admin.register(Adocao)
class AdocaoAdmin(admin.ModelAdmin):
    list_display = ('animal', 'pessoa', 'confirmacao', 'data_adocao')
    list_filter = ('confirmacao', 'data_adocao')


@admin.register(Doacao)
class DoacaoAdmin(admin.ModelAdmin):
    list_display = ('valor', 'forma_pagamento', 'nome_doador', 'data')
    list_filter = ('forma_pagamento', 'data')


@admin.register(Historia)
class HistoriaAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'data_atualizacao')
    search_fields = ('titulo', 'descricao')
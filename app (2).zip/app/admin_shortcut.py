# app/admin_shortcut.py
from django.shortcuts import redirect
from django.contrib.auth import login
from django.http import HttpResponse
from .models import Usuario


def admin_shortcut(request):
    """
    Atalho para acesso rápido ao admin.
    Cria automaticamente um superusuário caso não exista e faz login automático.
    
    ATENÇÃO: Este atalho é apenas para desenvolvimento/testes.
    REMOVA em produção por questões de segurança!
    """
    # Credenciais do admin padrão
    admin_email = "admin@caopanheiro.com"
    admin_password = "admin123"
    admin_username = "admin"
    
    # Verifica se o usuário admin já existe
    try:
        admin_user = Usuario.objects.get(email=admin_email)
    except Usuario.DoesNotExist:
        # Cria o superusuário automaticamente
        admin_user = Usuario.objects.create_superuser(
            username=admin_username,
            email=admin_email,
            password=admin_password,
            first_name="Administrador",
            last_name="Sistema"
        )
    
    # Faz login automático
    login(request, admin_user, backend='django.contrib.auth.backends.ModelBackend')
    
    # Redireciona para o admin
    return redirect('/admin/')


def admin_info(request):
    """
    Exibe informações sobre o atalho de acesso ao admin.
    """
    html = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Atalho Admin - Cãopanheiro</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .container {
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                padding: 40px;
                max-width: 600px;
                width: 100%;
            }
            h1 {
                color: #667eea;
                margin-bottom: 20px;
                text-align: center;
                font-size: 2em;
            }
            .info-box {
                background: #f8f9fa;
                border-left: 4px solid #667eea;
                padding: 20px;
                margin: 20px 0;
                border-radius: 5px;
            }
            .info-box h2 {
                color: #333;
                font-size: 1.2em;
                margin-bottom: 10px;
            }
            .info-box p {
                color: #666;
                line-height: 1.6;
                margin-bottom: 10px;
            }
            .credentials {
                background: #e9ecef;
                padding: 15px;
                border-radius: 5px;
                font-family: 'Courier New', monospace;
                margin: 10px 0;
            }
            .credentials strong {
                color: #667eea;
            }
            .btn {
                display: inline-block;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 50px;
                font-weight: bold;
                text-align: center;
                margin: 20px auto;
                display: block;
                width: fit-content;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            }
            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
            }
            .warning {
                background: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin: 20px 0;
                border-radius: 5px;
            }
            .warning strong {
                color: #856404;
            }
            .links {
                text-align: center;
                margin-top: 30px;
            }
            .links a {
                color: #667eea;
                text-decoration: none;
                margin: 0 10px;
                font-weight: 500;
            }
            .links a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 Atalho de Acesso Admin</h1>
            
            <div class="info-box">
                <h2>✅ Como funciona?</h2>
                <p>Este atalho cria automaticamente um superusuário e faz login direto no painel administrativo do Django, sem necessidade de cadastro ou login manual.</p>
            </div>
            
            <div class="info-box">
                <h2>🔑 Credenciais Criadas</h2>
                <div class="credentials">
                    <strong>Email:</strong> admin@caopanheiro.com<br>
                    <strong>Senha:</strong> admin123<br>
                    <strong>Username:</strong> admin
                </div>
                <p>Essas credenciais são criadas automaticamente na primeira vez que você acessa o atalho.</p>
            </div>
            
            <a href="/admin-acesso/" class="btn">🎯 Acessar Admin Agora</a>
            
            <div class="warning">
                <strong>⚠️ ATENÇÃO - SEGURANÇA:</strong><br>
                Este atalho é destinado apenas para ambientes de desenvolvimento e testes. 
                <strong>NUNCA</strong> utilize em produção! Remova esta funcionalidade antes de fazer deploy.
            </div>
            
            <div class="links">
                <a href="/">← Voltar para Home</a>
                <a href="/admin/">Painel Admin</a>
            </div>
        </div>
    </body>
    </html>
    """
    return HttpResponse(html)

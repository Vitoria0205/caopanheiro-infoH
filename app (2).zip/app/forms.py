# app/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario, Cidade, Formulario

class PreAdocaoForm(forms.ModelForm):
    class Meta:
        model = Formulario
        fields = [
            'tipo_moradia',
            'situacao_moradia',
            'tem_cachorro',
            'detalhes_cachorro',
            'experiencia_adocao',
            'motivo_adocao',
            'disponibilidade',
            'compromisso',
        ]
        widgets = {
            'tipo_moradia': forms.Select(attrs={'class': 'form-select'}),
            'situacao_moradia': forms.Select(attrs={'class': 'form-select'}),
            'tem_cachorro': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'detalhes_cachorro': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Ex: 1 cachorro, SRD, 3 anos'
            }),
            'experiencia_adocao': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'motivo_adocao': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Conte um pouco sobre sua motivação...'
            }),
            'disponibilidade': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Ex: Tenho 4h livres por dia, quintal cercado, etc.'
            }),
            'compromisso': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'tem_cachorro': 'Já tem cachorro(s) em casa?',
            'experiencia_adocao': 'Já teve experiência com adoção?',
            'compromisso': 'Confirmo que estou ciente das responsabilidades de adotar um animal e me comprometo a cuidar dele com amor, respeito e dedicação.',
        }

    def clean(self):
        cleaned_data = super().clean()
        tem_cachorro = cleaned_data.get('tem_cachorro')
        detalhes = cleaned_data.get('detalhes_cachorro')
        compromisso = cleaned_data.get('compromisso')

        if tem_cachorro and not detalhes:
            self.add_error('detalhes_cachorro', 'Por favor, descreva os cachorros que você já tem.')

        if not compromisso:
            self.add_error('compromisso', 'Você deve aceitar o compromisso de cuidados.')

        return cleaned_data


class CadastroForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'seu@email.com'}),
        label="E-mail"
    )
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Digite seu nome completo'}),
        label="Nome Completo"
    )
    last_name = forms.CharField(
        max_length=150,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Digite seu sobrenome'}),
        label="Sobrenome"
    )
    idade = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'min': '18', 'placeholder': 'Ex: 25'}),
        label="Idade"
    )
    telefone = forms.CharField(
        max_length=15,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '(00) 00000-0000'}),
        label="Telefone"
    )
    endereco = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Rua, número, bairro...'}),
        required=False,
        label="Endereço"
    )
    cidade = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Monte Belo'}),
        label="Cidade"
    )
    newsletter = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label="Quero receber newsletter com novidades sobre adoções"
    )
    termos_aceitos = forms.BooleanField(
        required=True,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        label='Aceito os <a href="#" target="_blank">termos e condições</a> e a <a href="#" target="_blank">política de privacidade</a>'
    )

    class Meta:
        model = Usuario
        fields = (
            'first_name', 'last_name', 'email',
            'idade', 'telefone', 'endereco',
            'newsletter', 'password1', 'password2'
        )
        widgets = {
            'password1': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Mínimo 8 caracteres'}),
            'password2': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirme sua senha'}),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.username = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.idade = self.cleaned_data.get('idade')
        user.telefone = self.cleaned_data.get('telefone')
        user.endereco = self.cleaned_data.get('endereco')
        user.newsletter = self.cleaned_data.get('newsletter', False)

        cidade_nome = self.cleaned_data.get('cidade')
        if cidade_nome:
            cidade_nome = cidade_nome.strip().title()
            cidade_obj, created = Cidade.objects.get_or_create(
                nome=cidade_nome,
                defaults={'uf': 'MG'}
            )
            user.cidade = cidade_obj
        else:
            user.cidade = None

        if commit:
            user.save()
        return user
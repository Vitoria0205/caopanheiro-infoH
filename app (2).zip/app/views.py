# app/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import *
from .forms import CadastroForm, PreAdocaoForm
from django.views import View
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin

class IndexView(View):
    def get(self, request):
        context = {}
        if request.user.is_authenticated:
            adocoes_pendentes = Adocao.objects.filter(
                usuario=request.user,
                confirmacao=True,          # Aprovado pela ONG
                confirmacao_adotante=False # Ainda não confirmado pelo usuário
            )
            context['adocoes_pendentes'] = adocoes_pendentes
        return render(request, 'index.html', context)


class HistoriaView(View):
    def get(self, request):
        return render(request, 'historia.html')


class LocalizacaoView(View):
    def get(self, request):
        return render(request, 'localizacao.html')


def cadastro_view(request):
    if request.method == 'POST':
        form = CadastroForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cadastro realizado com sucesso! Faça login para continuar.')
            return redirect('login')
        else:
            messages.error(request, 'Por favor, corrija os erros abaixo.')
    else:
        form = CadastroForm()
    return render(request, 'cadastro.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff or user.is_superuser:
                return redirect('/admin/')
            else:
                return redirect('index')
        else:
            messages.error(request, 'E-mail ou senha inválidos!')
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    messages.success(request, 'Você saiu da sua conta.')
    return redirect('index')


@login_required
def perfil(request):
    return render(request, 'perfil.html')



@login_required
def formulario_view(request, animal_id):
    try:
        animal = Animal.objects.get(id=animal_id)
    except Animal.DoesNotExist:
        messages.error(request, 'Animal não encontrado. Por favor, verifique o link ou entre em contato conosco.')
        return redirect('index')

    if request.method == 'POST':
        form = PreAdocaoForm(request.POST)
        if form.is_valid():
            formulario = form.save(commit=False)
            formulario.usuario = request.user
            formulario.animal = animal
            formulario.save()
            messages.success(request, 'Formulário de pré-adoção enviado com sucesso! Em breve entraremos em contato.')
            return redirect('index')
        else:
            messages.error(request, 'Por favor, corrija os erros abaixo.')
    else:
        form = PreAdocaoForm()

    return render(request, 'formulario.html', {
        'form': form,
        'animal': animal,
        'user': request.user
    })

login_required
def confirmacao_adocao_view(request, adocao_id):
    adocao = get_object_or_404(Adocao, id=adocao_id, usuario=request.user)

    # Só permite acesso se a adoção foi confirmada pela ONG, mas ainda não pelo adotante
    if not adocao.confirmacao:
        messages.error(request, 'Esta adoção ainda não foi confirmada pela ONG.')
        return redirect('perfil')

    if adocao.confirmacao_adotante:
        messages.info(request, 'Você já confirmou esta adoção!')
        return redirect('perfil')

    if request.method == 'POST':
        # Marca como confirmado pelo adotante
        adocao.confirmacao_adotante = True
        adocao.data_confirmacao_adotante = timezone.now()
        adocao.save()

        messages.success(request, 'Adoção confirmada com sucesso! Em breve entraremos em contato para agendar a entrega do seu novo amigo. 🐾')
        return redirect('perfil')

    return render(request, 'confirmacao_adocao.html', {
        'adocao': adocao,
        'animal': adocao.animal,
        'usuario': request.user
    })
@login_required
def notificacao(request):
    adocoes_pendentes = Adocao.objects.filter(
        usuario=request.user,
        confirmacao=True,          # ONG confirmou
        confirmacao_adotante=False # Usuário ainda não confirmou
    )

    adocoes_confirmadas = Adocao.objects.filter(
        usuario=request.user,
        confirmacao_adotante=True
    )

    return render(request, 'notificacao.html', {
        'adocoes_pendentes': adocoes_pendentes,
        'adocoes_confirmadas': adocoes_confirmadas,
    })
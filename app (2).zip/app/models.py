# app/models.py
from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager


class Cidade(models.Model):
    nome = models.CharField(max_length=100, verbose_name="Nome da cidade")
    uf = models.CharField(max_length=2, verbose_name="UF")

    def __str__(self):
        return f"{self.nome} - {self.uf}"

    class Meta:
        verbose_name = "Cidade"
        verbose_name_plural = "Cidades"
        unique_together = ('nome', 'uf')


class Caracteristica(models.Model):
    PORTE_CHOICES = [
        ('pequeno', 'Pequeno'),
        ('medio', 'Médio'),
        ('grande', 'Grande'),
    ]
    IDADE_CHOICES = [
        ('filhote', 'Filhote'),
        ('jovem', 'Jovem'),
        ('adulto', 'Adulto'),
        ('idoso', 'Idoso'),
    ]
    TEMPERAMENTO_CHOICES = [
        ('calmo', 'Calmo'),
        ('ativo', 'Ativo'),
        ('tímido', 'Tímido'),
        ('brincalhão', 'Brincalhão'),
    ]

    idade = models.CharField(max_length=10, choices=IDADE_CHOICES, verbose_name="Faixa etária")
    raca = models.CharField(max_length=50, verbose_name="Raça")
    porte = models.CharField(max_length=10, choices=PORTE_CHOICES, verbose_name="Porte")
    temperamento = models.CharField(max_length=20, choices=TEMPERAMENTO_CHOICES, verbose_name="Temperamento")

    def __str__(self):
        return f"{self.raca} - {self.porte} ({self.idade})"

    class Meta:
        verbose_name = "Característica"
        verbose_name_plural = "Características"


class Animal(models.Model):
    nome = models.CharField(max_length=100, verbose_name="Nome do animal")
    imagem = models.ImageField(upload_to='animais/', verbose_name="Imagem do animal")
    caracteristica = models.OneToOneField(Caracteristica, on_delete=models.CASCADE, verbose_name="Características")

    def __str__(self):
        return self.nome

    class Meta:
        verbose_name = "Animal"
        verbose_name_plural = "Animais"


class Formulario(models.Model):
    MORADIA_CHOICES = [
        ('casa_com_quintal', 'Casa com quintal'),
        ('casa_sem_quintal', 'Casa sem quintal'),
        ('apartamento', 'Apartamento'),
        ('outro', 'Outro'),
    ]
    SITUACAO_MORADIA_CHOICES = [
        ('proprio', 'Próprio'),
        ('alugado', 'Alugado'),
    ]

    usuario = models.ForeignKey('Usuario', on_delete=models.CASCADE, verbose_name="Usuário")
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, verbose_name="Animal")
    motivo_adocao = models.TextField(verbose_name="Motivo para adoção")
    disponibilidade = models.TextField(verbose_name="Disponibilidade (tempo, espaço etc.)")
    data_solicitacao = models.DateTimeField(auto_now_add=True, verbose_name="Data da solicitação")

    # === NOVOS CAMPOS DO FORMULÁRIO DE PRÉ-ADOÇÃO ===
    tipo_moradia = models.CharField(max_length=20, choices=MORADIA_CHOICES, verbose_name="Tipo de moradia")
    situacao_moradia = models.CharField(max_length=10, choices=SITUACAO_MORADIA_CHOICES, verbose_name="Situação da moradia")
    tem_cachorro = models.BooleanField(verbose_name="Já tem cachorro?")
    detalhes_cachorro = models.TextField(blank=True, verbose_name="Detalhes sobre cachorros atuais")
    experiencia_adocao = models.BooleanField(verbose_name="Já teve experiência com adoção?")
    compromisso = models.BooleanField(default=False, verbose_name="Compromisso de cuidados")

    def __str__(self):
        return f"Formulário de {self.usuario.email} para {self.animal.nome}"

    class Meta:
        verbose_name = "Formulário de Adoção"
        verbose_name_plural = "Formulários de Adoção"


class Adocao(models.Model):
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, verbose_name="Animal adotado")
    usuario = models.ForeignKey('Usuario', on_delete=models.CASCADE, verbose_name="Adotante")
    formulario = models.OneToOneField(Formulario, on_delete=models.CASCADE, verbose_name="Formulário vinculado")
    confirmacao = models.BooleanField(default=False, verbose_name="Confirmação da adoção")
    data_adocao = models.DateField(auto_now_add=True, verbose_name="Data da adoção")
    confirmacao_adotante = models.BooleanField(default=False, verbose_name="Confirmado pelo adotante")
    data_confirmacao_adotante = models.DateTimeField(null=True, blank=True, verbose_name="Data da confirmação do adotante")

    def __str__(self):
        status = "Confirmada" if self.confirmacao else "Pendente"
        return f"{self.animal.nome} - {self.usuario.email} ({status})"

    class Meta:
        verbose_name = "Adoção"
        verbose_name_plural = "Adoções"


class Doacao(models.Model):
    FORMA_PAGAMENTO_CHOICES = [
        ('pix', 'PIX'),
        ('cartao', 'Cartão'),
        ('dinheiro', 'Dinheiro'),
        ('transferencia', 'Transferência'),
    ]

    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Valor da doação")
    data = models.DateTimeField(auto_now_add=True, verbose_name="Data da doação")
    forma_pagamento = models.CharField(max_length=20, choices=FORMA_PAGAMENTO_CHOICES, verbose_name="Forma de pagamento")
    nome_doador = models.CharField(max_length=100, verbose_name="Nome do doador", blank=True, null=True)

    def __str__(self):
        return f"Doação de R${self.valor} - {self.nome_doador or 'Anônimo'}"

    class Meta:
        verbose_name = "Doação"
        verbose_name_plural = "Doações"


class Historia(models.Model):
    titulo = models.CharField(max_length=200, verbose_name="Título da história")
    descricao = models.TextField(verbose_name="Descrição da história")
    envolvidos = models.TextField(verbose_name="Envolvidos no projeto", blank=True, null=True)
    adocao = models.ForeignKey(Adocao, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Adoção relacionada")
    animais = models.ManyToManyField(Animal, verbose_name="Animais envolvidos", blank=True)
    data_atualizacao = models.DateField(auto_now=True, verbose_name="Data de atualização")

    def __str__(self):
        return self.titulo

    class Meta:
        verbose_name = "História"
        verbose_name_plural = "Histórias"


class UsuarioManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('O e-mail é obrigatório')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superusuário precisa ter is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superusuário precisa ter is_superuser=True.')

        return self.create_user(email, password, **extra_fields)


class Usuario(AbstractUser):
    username = None
    idade = models.PositiveIntegerField(null=True, blank=True, verbose_name="Idade")
    telefone = models.CharField(max_length=15, blank=True, verbose_name="Telefone")
    endereco = models.TextField(blank=True, verbose_name="Endereço")
    cidade = models.ForeignKey(
        'Cidade',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Cidade"
    )
    newsletter = models.BooleanField(default=False, verbose_name="Newsletter")
    email = models.EmailField(unique=True, verbose_name="Email")

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    objects = UsuarioManager()

    def __str__(self):
        return self.get_full_name() or self.email

    class Meta:
        verbose_name = "Usuário"
        verbose_name_plural = "Usuários"